# DON OMAR RADIO PLAYER

Aplicación Android nativa mínima para reproducir el directo del canal `donomar_radio_medellin` de Twitch.

## Funciones
- Reproducir y detener.
- Servicio multimedia Android (Media3 `MediaSessionService`) para reproducción en segundo plano.
- Solicitud de la variante HLS `audio_only` cuando Twitch la ofrece.
- Reconexión progresiva automática tras cortes de red o errores del reproductor.
- Notificación de reproducción del sistema.

## Compilación
El proyecto requiere JDK 17, Android SDK 35 y Gradle 8.9. El flujo de GitHub Actions incluido compila `app-debug.apk` y lo publica como artefacto descargable en la ejecución.

## Importante
Este código fuente no es un APK compilado. El acceso a HLS de Twitch depende de interfaces de reproducción no documentadas públicamente y puede cambiar por decisión de Twitch. La primera compilación debe probarse en un teléfono Android real, incluida la prueba con pantalla bloqueada y cambio de aplicación. No se afirma que esté probado hasta completar esas pruebas.
