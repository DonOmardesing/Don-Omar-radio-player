package com.donomar.radioplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(5, 8, 18))
        }
        val title = TextView(this).apply {
            text = "DON OMAR RADIO\nPLAYER"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(0, 190, 255))
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "RADIO SESSIONS MEDELLÍN"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        val play = Button(this).apply {
            text = "REPRODUCIR EN VIVO"
            setOnClickListener {
                val intent = Intent(this@MainActivity, RadioService::class.java)
                    .setAction(RadioService.ACTION_PLAY)
                ContextCompat.startForegroundService(this@MainActivity, intent)
            }
        }
        val stop = Button(this).apply {
            text = "DETENER"
            setOnClickListener {
                // A stop command must not start a new foreground service.
                startService(Intent(this@MainActivity, RadioService::class.java)
                    .setAction(RadioService.ACTION_STOP))
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(play, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 40 })
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        setContentView(layout)
    }
}
