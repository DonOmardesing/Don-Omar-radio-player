package com.donomar.radioplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RadioService : MediaSessionService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var reconnectJob: Job? = null
    private var connectJob: Job? = null
    private var manuallyStopped = false
    private var retryCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            setWakeMode(C.WAKE_MODE_LOCAL)
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    scheduleReconnect()
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) retryCount = 0
                }
            })
        }
        mediaSession = MediaSession.Builder(this, player!!).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_PLAY -> {
                reconnectJob?.cancel()
                manuallyStopped = false
                retryCount = 0
                startForeground(NOTIFICATION_ID, buildNotification("Conectando con Twitch…"))
                connectToLive()
            }
            ACTION_STOP -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    private fun connectToLive() {
        reconnectJob = null
        connectJob?.cancel()
        connectJob = serviceScope.launch {
            try {
                updateNotification("Conectando con Twitch…")
                val url = withContext(Dispatchers.IO) {
                    TwitchResolver.resolve(CHANNEL)
                }
                if (manuallyStopped) return@launch
                player?.apply {
                    setMediaItem(MediaItem.fromUri(url))
                    prepare()
                    playWhenReady = true
                    play()
                }
                updateNotification("En vivo · $CHANNEL")
            } catch (error: Exception) {
                if (!manuallyStopped) scheduleReconnect()
            }
        }
    }

    private fun scheduleReconnect() {
        if (manuallyStopped || reconnectJob?.isActive == true) return
        reconnectJob = serviceScope.launch {
            val waits = longArrayOf(5, 10, 20, 30, 45, 60)
            val waitSeconds = waits[retryCount.coerceAtMost(waits.lastIndex)]
            retryCount++
            updateNotification("Señal interrumpida · reconectando en ${waitSeconds}s")
            delay(waitSeconds * 1000)
            reconnectJob = null
            if (!manuallyStopped) connectToLive()
        }
    }

    private fun stopPlayback() {
        manuallyStopped = true
        reconnectJob?.cancel()
        connectJob?.cancel()
        player?.apply {
            playWhenReady = false
            stop()
            clearMediaItems()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "DON OMAR RADIO", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("DON OMAR RADIO PLAYER")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onDestroy() {
        manuallyStopped = true
        reconnectJob?.cancel()
        connectJob?.cancel()
        serviceScope.cancel()
        mediaSession?.release()
        player?.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.donomar.radioplayer.PLAY"
        const val ACTION_STOP = "com.donomar.radioplayer.STOP"
        private const val CHANNEL_ID = "don_omar_radio_playback"
        private const val NOTIFICATION_ID = 4107
        private const val CHANNEL = "donomar_radio_medellin"
    }
}
