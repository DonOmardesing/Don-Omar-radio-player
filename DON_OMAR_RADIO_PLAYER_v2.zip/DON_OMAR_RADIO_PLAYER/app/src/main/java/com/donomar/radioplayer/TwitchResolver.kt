package com.donomar.radioplayer

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Resolves the public live HLS playlist for the configured Twitch channel. */
object TwitchResolver {
    private const val FALLBACK_CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    fun resolve(channel: String): String {
        val login = channel.trim().lowercase()
        require(login.matches(Regex("[a-z0-9_]{1,25}"))) { "Nombre de canal Twitch no válido" }
        val clientId = findClientId(login)
        val query = """query PlaybackAccessToken(${'$'}login: String!, ${'$'}playerType: String!) {
            streamPlaybackAccessToken(channelName: ${'$'}login,
              params: {platform: "web", playerBackend: "mediaplayer", playerType: ${'$'}playerType}) {
              value signature
            }
        }"""
        val payload = JSONObject()
            .put("query", query)
            .put("variables", JSONObject().put("login", login).put("playerType", "embed"))
        val tokenRequest = Request.Builder()
            .url("https://gql.twitch.tv/gql")
            .header("Client-Id", clientId)
            .header("Origin", "https://www.twitch.tv")
            .header("Referer", "https://www.twitch.tv/$login")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val tokenData = http.newCall(tokenRequest).execute().use { response ->
            check(response.isSuccessful) { "Twitch token HTTP ${response.code}" }
            val body = JSONObject(response.body?.string().orEmpty())
            check(!body.has("errors")) { "Twitch rechazó la solicitud de reproducción" }
            body.getJSONObject("data").getJSONObject("streamPlaybackAccessToken")
        }
        val signature = tokenData.getString("signature")
        val token = tokenData.getString("value")

        val masterUrl = "https://usher.ttvnw.net/api/channel/hls/$login.m3u8".toHttpUrl()
            .newBuilder()
            .addQueryParameter("sig", signature)
            .addQueryParameter("token", token)
            .addQueryParameter("allow_source", "true")
            .addQueryParameter("allow_audio_only", "true")
            .addQueryParameter("fast_bread", "true")
            .addQueryParameter("platform", "web")
            .addQueryParameter("player", "twitchweb")
            .addQueryParameter("p", (1..999999).random().toString())
            .build()
            .toString()

        val playlistRequest = Request.Builder()
            .url(masterUrl)
            .header("Origin", "https://www.twitch.tv")
            .header("Referer", "https://www.twitch.tv/$login")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
            .build()
        val playlist = http.newCall(playlistRequest).execute().use { response ->
            check(response.isSuccessful) { "Twitch playlist HTTP ${response.code}" }
            response.body?.string().orEmpty()
        }
        check(playlist.isNotBlank() && !playlist.trimStart().startsWith("{")) {
            "Twitch no entregó una lista HLS válida"
        }

        val lines = playlist.lines()
        for (index in lines.indices) {
            val header = lines[index].trim()
            if (!header.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) continue
            val isAudio = header.contains("audio_only", ignoreCase = true) ||
                Regex("VIDEO=\"audio\"", RegexOption.IGNORE_CASE).containsMatchIn(header)
            if (!isAudio) continue
            val uri = lines.drop(index + 1).firstOrNull {
                it.isNotBlank() && !it.trim().startsWith("#")
            }?.trim()
            if (uri != null) {
                return masterUrl.toHttpUrl().resolve(uri)?.toString() ?: uri
            }
        }
        // Some Twitch sessions do not publish an audio_only rendition. ExoPlayer can
        // still consume the master HLS playlist without attaching a video surface.
        return masterUrl
    }

    private fun findClientId(channel: String): String {
        return try {
            val request = Request.Builder()
                .url("https://www.twitch.tv/$channel")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
                .build()
            http.newCall(request).execute().use { response ->
                val html = response.body?.string().orEmpty()
                Regex("clientId=\"([a-zA-Z0-9]+)\"")
                    .find(html)?.groupValues?.getOrNull(1) ?: FALLBACK_CLIENT_ID
            }
        } catch (_: Exception) {
            FALLBACK_CLIENT_ID
        }
    }
}
